**To create an Internet gateway**

This example creates an Internet gateway.

Command::

  aws ec2 create-internet-gateway 

Output::

  {
      "InternetGateway": {
          "Tags": [],
          "InternetGatewayId": "igw-c0a643a9",
          "Attachments": []
      }
  }